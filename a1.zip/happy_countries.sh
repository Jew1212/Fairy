#!/bin/bash
                                                                         
                                                                       
data=$(curl -s https://en.wikipedia.org/wiki/World_Happiness_Report?action=raw)

origin=$(echo "$data"| awk '/===2018 report/,/{{collapse bottom}}/' | sed -n '/| 1||/,/| 10||/p' | sed 'n;d;')   

echo "$origin" | sed 's/\}.*$//' | awk '{print $NF}' FS=\|
                                      
              


            
                                   
