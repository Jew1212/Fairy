while IFS=, read -r f_name l_name birth_d
do
	                               
	year=$(echo $birth_d | head -c 4)

	if [[ 1899 -le $year ]]
	then
		if [[ $year -le 2442 ]]
		then
			                
			x=$(expr 2021 - $year)
			if [[ $x -gt 18 && $x -le 2021 ]]
			then
				echo "Dear Mr/Mrs $l_name, $f_name"
			fi
		else
			              
			y=$(expr 2564 - $year)
			if [[ $y -gt 18 && $x -le 2564 ]]
			then
				echo "Dear Mr/Mrs $l_name, $f_name"
			fi

		fi
	fi
	     
		                                 
	  

  
done < $1


