             
x=$(du -sk $1 | tr -dc '0-9')
    
       

if [[ $x -lt 1000 ]];then
	echo 'Low'
elif [[ $x -lt 5000 ]];then
	echo 'Medium'
else
	echo 'High'
	echo '$1' >> ListOfBigDirs.txt
fi

  




                         
	          
                             
	             
    
	             
	                                
  


