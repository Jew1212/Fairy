        
#!/bin/bash 
cd $2    
ls
for f in *       
do
	echo $f
	if [[ $f == *.$1 ]];then
		file=$f
		replace=${file%.*}
		mv $f $replace
	fi
	              
done

	       
                     
	       
		         
		                      
		              
	  
    




