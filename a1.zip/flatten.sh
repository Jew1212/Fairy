unzip -d $2 $1       
#s $2

     

find $2 -depth -type f -print0 | while read -d '' file
do
	mv $file $2
done

#s $2  

find $2 -mindepth 1 -type d -print0 | while read -d '' folder
do
	rm -r $folder
done

#s $2
